/*
 * This code is sample code, provided as-is, and we make NO 
 * warranties as to its correctness or suitability for any purpose.
 * 
 * We hope that it's useful to you. Enjoy. 
 * Copyright LearningPatterns Inc.
 */
 
package com.javatunes.config;


import com.javatunes.persistence.ItemRepository;
import com.javatunes.service.Catalog;
import com.javatunes.service.CatalogImpl;

// TODO: Declare as a configuration class
public class SpringServicesConfig {
	
	// TODO: Inject the repository
	ItemRepository repository;

	// TODO: Declare the catalog bean definition

}