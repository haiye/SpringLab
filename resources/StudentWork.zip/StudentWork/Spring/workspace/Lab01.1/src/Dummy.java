/** 
 * This class is only here to cause Eclipse to include the src folder on the build path.
 * Otherwise, it's likely to not include it, which means we'd need to add it manually since it has
 * configuration files in it (Spring and logging). 
 */

public class Dummy {

}
