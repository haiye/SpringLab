/*
 * This code is sample code, provided as-is, and we make NO 
 * warranties as to its correctness or suitability for any purpose.
 * 
 * We hope that it's useful to you. Enjoy. 
 * Copyright LearningPatterns Inc.
 */

package com.javatunes.batch;

import com.javatunes.domain.MusicItem;

// A simple writer for Person items
// TODO: Implement the correct type to be an item reader for MusicItem instances
public class MusicItemWriter  {

	// TODO: Create a write method

}
